package com.piratefirst.sovereignreader

import android.annotation.SuppressLint
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ready = false
    private val voices = LinkedHashMap<String, Voice>()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.webViewClient = WebViewClient()

        // This interface is only exposed to our own packaged HTML asset.
        webView.addJavascriptInterface(TtsBridge(), "AndroidTTS")
        webView.loadUrl("file:///android_asset/index.html")

        tts = TextToSpeech(this) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        // No-op; JS controls the visual state.
                    }

                    override fun onDone(utteranceId: String?) {
                        val id = JSONObject.quote(utteranceId ?: "")
                        runOnUiThread {
                            webView.evaluateJavascript(
                                "window.nativeTtsDone && window.nativeTtsDone($id);",
                                null
                            )
                        }
                    }

                    override fun onError(utteranceId: String?) {
                        val id = JSONObject.quote(utteranceId ?: "")
                        runOnUiThread {
                            webView.evaluateJavascript(
                                "window.nativeTtsError && window.nativeTtsError($id);",
                                null
                            )
                        }
                    }

                    // Android 8+ provides actual character-range callbacks.
                    // The JS layer maps these ranges back to words.
                    override fun onRangeStart(
                        utteranceId: String?,
                        start: Int,
                        end: Int,
                        frame: Int
                    ) {
                        val id = JSONObject.quote(utteranceId ?: "")
                        runOnUiThread {
                            webView.evaluateJavascript(
                                "window.nativeTtsRange && window.nativeTtsRange($id,$start,$end);",
                                null
                            )
                        }
                    }
                })
                refreshVoices()
            }
        }
    }

    private fun refreshVoices() {
        val set = tts?.voices ?: emptySet()
        voices.clear()
        for (voice in set) {
            val lang = voice.locale?.toLanguageTag() ?: continue
            if (!Regex("^(en|fr|es)(-|$)", RegexOption.IGNORE_CASE).containsMatchIn(lang)) continue
            voices[voice.name] = voice
        }
    }

    private inner class TtsBridge {
        @JavascriptInterface
        fun isReady(): Boolean = ready

        @JavascriptInterface
        fun getVoices(): String {
            refreshVoices()
            val arr = JSONArray()
            voices.values
                .sortedWith(compareBy<Voice>({ languageRank(it.locale) }, { it.name.lowercase() }))
                .forEach { voice ->
                    val o = JSONObject()
                    o.put("id", voice.name)
                    o.put("name", displayVoiceName(voice))
                    o.put("engineName", voice.name)
                    o.put("lang", voice.locale.toLanguageTag())
                    o.put("network", voice.isNetworkConnectionRequired)
                    o.put("features", voice.features.joinToString(","))
                    arr.put(o)
                }
            return arr.toString()
        }

        @JavascriptInterface
        fun setVoice(id: String): Boolean {
            val voice = voices[id] ?: tts?.voices?.firstOrNull { it.name == id }
            return if (voice != null && ready) {
                tts?.setVoice(voice) == TextToSpeech.SUCCESS
            } else false
        }

        @JavascriptInterface
        fun speak(text: String, utteranceId: String, rate: Float): Boolean {
            if (!ready) return false
            tts?.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
            val result = tts?.speak(
                text,
                TextToSpeech.QUEUE_FLUSH,
                null,
                utteranceId
            ) ?: TextToSpeech.ERROR
            return result == TextToSpeech.SUCCESS
        }

        @JavascriptInterface
        fun stop() {
            tts?.stop()
        }

        @JavascriptInterface
        fun shutdown() {
            tts?.stop()
        }
    }

    private fun languageRank(locale: Locale): Int = when (locale.language.lowercase()) {
        "en" -> 0
        "fr" -> 1
        "es" -> 2
        else -> 9
    }

    private fun displayVoiceName(voice: Voice): String {
        val raw = voice.name
        val lower = raw.lowercase()
        // Google voice IDs commonly expose gender in their internal name.
        return when {
            lower.contains("female") -> "Female · ${voice.locale.toLanguageTag()}"
            lower.contains("male") -> "Male · ${voice.locale.toLanguageTag()}"
            else -> raw
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
