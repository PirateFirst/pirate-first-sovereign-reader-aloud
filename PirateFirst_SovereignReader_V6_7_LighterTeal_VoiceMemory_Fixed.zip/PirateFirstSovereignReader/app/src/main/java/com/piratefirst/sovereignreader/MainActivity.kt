package com.piratefirst.sovereignreader

import android.annotation.SuppressLint
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ready = false
    private val voices = LinkedHashMap<String, Voice>()
    private var selectedLocale: Locale = Locale.US

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val savedOrientation = getPreferences(MODE_PRIVATE).getInt("orientation", android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)
        requestedOrientation = savedOrientation
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false

        // Serve our bundled HTML through WebViewAssetLoader. This avoids file://
        // origin quirks while keeping local content isolated from arbitrary files.
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }

        // This interface is only exposed to our own packaged HTML asset.
        webView.addJavascriptInterface(TtsBridge(), "AndroidTTS")
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        tts = TextToSpeech(this) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        // No-op; JS controls the visual state.
                    }

                    override fun onDone(utteranceId: String?) {
                        val id = JSONObject.quote(utteranceId ?: "")
                        runOnUiThread {
                            webView.evaluateJavascript(
                                "window.nativeTtsDone && window.nativeTtsDone($id);",
                                null
                            )
                        }
                    }

                    override fun onError(utteranceId: String?) {
                        val id = JSONObject.quote(utteranceId ?: "")
                        runOnUiThread {
                            webView.evaluateJavascript(
                                "window.nativeTtsError && window.nativeTtsError($id);",
                                null
                            )
                        }
                    }

                    // Android 8+ provides actual character-range callbacks.
                    // The JS layer maps these ranges back to words.
                    override fun onRangeStart(
                        utteranceId: String?,
                        start: Int,
                        end: Int,
                        frame: Int
                    ) {
                        val id = JSONObject.quote(utteranceId ?: "")
                        runOnUiThread {
                            webView.evaluateJavascript(
                                "window.nativeTtsRange && window.nativeTtsRange($id,$start,$end);",
                                null
                            )
                        }
                    }
                })
                refreshVoices()
                // Some Android TTS engines expose no Voice objects immediately (or at all)
                // even though language synthesis is available. Keep the bridge usable.
            }
        }
    }

    private fun refreshVoices() {
        val set = tts?.voices ?: emptySet()
        voices.clear()
        for (voice in set) {
            val lang = voice.locale?.toLanguageTag() ?: continue
            if (!Regex("^(en|fr|es)(-|$)", RegexOption.IGNORE_CASE).containsMatchIn(lang)) continue
            voices[voice.name] = voice
        }
    }

    private inner class TtsBridge {
        @JavascriptInterface
        fun isReady(): Boolean = ready

        @JavascriptInterface
        fun getVoices(): String {
            refreshVoices()
            val arr = JSONArray()
            voices.values
                .sortedWith(compareBy<Voice>({ languageRank(it.locale) }, { it.name.lowercase() }))
                .forEach { voice ->
                    val o = JSONObject()
                    o.put("id", voice.name)
                    o.put("name", displayVoiceName(voice))
                    o.put("engineName", voice.name)
                    o.put("lang", voice.locale.toLanguageTag())
                    o.put("network", voice.isNetworkConnectionRequired)
                    o.put("features", voice.features.joinToString(","))
                    o.put("native", true)
                    o.put("source", "LOCAL · Android")
                    arr.put(o)
                }

            // Fallback: several Android TTS engines can synthesize by Locale while
            // reporting an empty Voice set. Expose language choices so the reader
            // remains usable instead of falling back to RSVP-only mode.
            if (arr.length() == 0 && ready) {
                listOf(
                    Triple("fallback-en-US", "English (United States)", Locale.US),
                    Triple("fallback-fr-FR", "French (France)", Locale.FRANCE),
                    Triple("fallback-es-MX", "Spanish (Mexico)", Locale("es", "MX"))
                ).forEach { (id, name, locale) ->
                    val o = JSONObject()
                    o.put("id", id)
                    o.put("name", name)
                    o.put("engineName", id)
                    o.put("lang", locale.toLanguageTag())
                    o.put("network", false)
                    o.put("features", "")
                    o.put("native", false)
                    o.put("source", "LOCAL · Android · Locale")
                    arr.put(o)
                }
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun setVoice(id: String): Boolean {
            if (!ready) return false

            // Handle synthetic locale choices when the engine exposes no Voice objects.
            val fallbackLocale = when (id) {
                "fallback-en-US" -> Locale.US
                "fallback-fr-FR" -> Locale.FRANCE
                "fallback-es-MX" -> Locale("es", "MX")
                else -> null
            }
            if (fallbackLocale != null) {
                selectedLocale = fallbackLocale
                return tts?.setLanguage(fallbackLocale)?.let {
                    it != TextToSpeech.LANG_MISSING_DATA && it != TextToSpeech.LANG_NOT_SUPPORTED
                } ?: false
            }

            val voice = voices[id] ?: tts?.voices?.firstOrNull { it.name == id }
            return if (voice != null) {
                selectedLocale = voice.locale
                tts?.setVoice(voice) == TextToSpeech.SUCCESS
            } else false
        }

        @JavascriptInterface
        fun speak(text: String, utteranceId: String, rate: Float): Boolean {
            if (!ready) return false
            tts?.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
            // Keep synthesis usable even when the engine exposes an empty Voice list.
            if (voices.isEmpty()) {
                val langResult = tts?.setLanguage(selectedLocale) ?: TextToSpeech.ERROR
                if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    return false
                }
            }
            val result = tts?.speak(
                text,
                TextToSpeech.QUEUE_FLUSH,
                null,
                utteranceId
            ) ?: TextToSpeech.ERROR
            return result == TextToSpeech.SUCCESS
        }

        @JavascriptInterface
        fun getOrientation(): String {
            return if (requestedOrientation == android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) "portrait" else "landscape"
        }

        @JavascriptInterface
        fun setOrientation(mode: String): Boolean {
            val portrait = mode.equals("portrait", ignoreCase = true)
            val value = if (portrait) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                        else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            getPreferences(MODE_PRIVATE).edit().putInt("orientation", value).apply()
            requestedOrientation = value
            return true
        }

        @JavascriptInterface
        fun stop() {
            tts?.stop()
        }

        @JavascriptInterface
        fun shutdown() {
            tts?.stop()
        }
    }

    private fun languageRank(locale: Locale): Int = when (locale.language.lowercase()) {
        "en" -> 0
        "fr" -> 1
        "es" -> 2
        else -> 9
    }

    private fun displayVoiceName(voice: Voice): String {
        val raw = voice.name.lowercase()
        val locale = voice.locale
        val language = when (locale.language.lowercase()) {
            "en" -> "English"
            "fr" -> "French"
            "es" -> "Spanish"
            else -> locale.displayLanguage.replaceFirstChar { it.uppercase() }
        }
        val region = locale.country.takeIf { it.isNotBlank() }?.let {
            Locale("", it).displayCountry
        }.orEmpty()

        val gender = when {
            raw.contains("voice v") || raw.contains("voice_v") -> "Voice V · Male"
            raw.contains("voice vi") || raw.contains("voice_vi") -> "Voice VI · Female"
            raw.contains("female") || raw.contains("fem") -> "Female"
            raw.contains("male") || raw.contains("masc") -> "Male"
            else -> "Voice"
        }
        return if (region.isNotBlank()) "$language · $gender · $region" else "$language · $gender"
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
