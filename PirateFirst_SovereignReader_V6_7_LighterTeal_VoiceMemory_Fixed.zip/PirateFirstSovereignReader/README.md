# Pirate First · Sovereign Reader — Android

This project packages the existing Sovereign Reader HTML inside an Android WebView and routes speech through Android's native `TextToSpeech` API.

Why: Chrome's Web Speech API on the target phone exposes only locale-level voices, while Android's native TTS API can enumerate and select the actual `Voice` objects exposed by the installed TTS engine.

## Build

Open this folder in Android Studio and let Gradle sync.

- Minimum Android: 6.0 (API 23)
- Target: API 35
- Native TTS voice enumeration: API 21+
- WebView ↔ native bridge: Android `JavascriptInterface`
- The app is offline-capable except for TTS voices marked as network-required.

## Voice V / VI

The app exposes the native Android voices returned by `TextToSpeech.getVoices()`. If the installed Google TTS engine exposes the US-English variants as Voice V / Voice VI internally, the reader can select those actual voice objects. The browser-only version could not see those variants.

If Android exposes them under opaque engine IDs instead, the app displays those native IDs rather than inventing a mapping.

## Build APK

In Android Studio: Build → Build Bundle(s) / APK(s) → Build APK(s).

